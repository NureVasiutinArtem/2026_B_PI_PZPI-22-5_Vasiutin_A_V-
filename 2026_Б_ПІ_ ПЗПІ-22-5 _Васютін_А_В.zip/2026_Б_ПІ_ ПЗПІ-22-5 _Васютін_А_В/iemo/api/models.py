from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import MinValueValidator, MaxValueValidator
from .ai import create_embedding

class User(AbstractUser):
    avatar_url = models.URLField(blank=True, null=True)
    points = models.IntegerField(default=0, verbose_name="Балобонусы")
    
    @property
    def rank(self):
        """Звания на основе опыта исследования музыки"""
        if self.points < 100: return "Новачок"
        if self.points < 500: return "Меломан"
        if self.points < 1500: return "Золотий вухач"
        return "Музичний сомельє"

    def __str__(self):
        return f"{self.username} ({self.rank})"

class AudioTrack(models.Model):
    title = models.CharField(max_length=200)
    audio_file = models.FileField(upload_to='tracks/')
    mood_emoji = models.CharField(max_length=10, default='🎵')
    created_at = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='tracks', null=True, blank=True)

    def __str__(self):
        return self.title

class ResearcherComment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='research_comments')
    track = models.ForeignKey(AudioTrack, on_delete=models.CASCADE, related_name='research_data')
    content = models.TextField() # Текст: "драйвово", "феерично" и т.д.
    
    embedding_vector = models.JSONField(null=True, blank=True)
    
    rating = models.FloatField(default=0.0)
    useful_count = models.IntegerField(default=0)

    def save(self, *args, **kwargs):
       
        if self.content and not self.embedding_vector:
          
            vector_ndarray = create_embedding(self.content)
            self.embedding_vector = vector_ndarray.tolist()
            
        super(ResearcherComment, self).save(*args, **kwargs)

    def __str__(self):
        return f"Анализ от {self.user.username} (Трек: {self.track.title})"

class SearchLog(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='search_history')
    query_text = models.TextField()
    
    matched_track = models.ForeignKey(AudioTrack, on_delete=models.SET_NULL, null=True)
    best_matching_comment = models.ForeignKey(ResearcherComment, on_delete=models.SET_NULL, null=True)
    
    user_feedback_score = models.IntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        null=True, blank=True
    )
    
    similarity_score = models.FloatField(default=0.0) 
    created_at = models.DateTimeField(auto_now_add=True)



class Like(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='likes')
    track = models.ForeignKey(AudioTrack, on_delete=models.CASCADE, related_name='likes')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'track')

class Repost(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reposts')
    track = models.ForeignKey(AudioTrack, on_delete=models.CASCADE, related_name='reposts')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'track')

# 5. СИСТЕМА ДОСТИЖЕНИЙ (АЧИВКИ)
class Achievement(models.Model):
    TYPE_CHOICES = [
        ('fives', 'За оцінку 5'),
        ('count', 'За кількість оцінок'),
        ('top', 'За ТОП-10'),
    ]
    title = models.CharField(max_length=100)
    description = models.TextField()
    icon_name = models.CharField(max_length=50) 
    achievement_type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    condition_value = models.IntegerField(default=0) 

    def __str__(self):
        return self.title

class UserAchievement(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='achievements')
    achievement = models.ForeignKey(Achievement, on_delete=models.CASCADE)
    awarded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'achievement')