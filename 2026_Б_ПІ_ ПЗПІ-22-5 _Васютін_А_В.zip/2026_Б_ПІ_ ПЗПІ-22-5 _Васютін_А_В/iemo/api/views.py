from rest_framework import generics, viewsets, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.authtoken.models import Token
from django.contrib.auth import login, logout
from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
import numpy as np
from .ai import cosine_similarity, create_embedding
from drf_yasg.utils import swagger_auto_schema
# Імпорт моделей та серіалізаторів IEmotion
from .models import (
    User, AudioTrack, ResearcherComment, 
    SearchLog, Achievement, UserAchievement, Like, Repost
)
from .serializers import (
    AISearchTextSerializer, RegisterSerializer, UserSerializer, AudioTrackSerializer, 
    ResearcherCommentSerializer, SearchLogSerializer, 
    AchievementSerializer, UserAchievementSerializer
)


def login_page(request):
    tracks = AudioTrack.objects.all()
    return render(request, 'login.html', {'tracks': tracks})

def search_view(request):
    tracks = AudioTrack.objects.all()
    return render(request, "search.html", {"tracks": tracks})

def research_page(request):
    tracks = AudioTrack.objects.all()
    res_com = ResearcherComment.objects.all()
    
    return render(request, 'researcher.html', {'tracks': tracks, 'researcher_comments': res_com})

@login_required
def profile_view(request):
    user = request.user
    # tracks = AudioTrack.objects.filter(user=user)
    tracks = (AudioTrack.objects.filter(user=user) | AudioTrack.objects.filter(reposts__user=user)).distinct()
    likes_count = Like.objects.filter(user=user).count()
    comments = ResearcherComment.objects.filter(track__user=user).order_by("-id")[:3]
    
    liked_track_ids = set(Like.objects.filter(user=user).values_list('track_id', flat=True))
    reposted_track_ids = set(Repost.objects.filter(user=user).values_list('track_id', flat=True))

    return render(request, "profile.html", {
        "tracks": tracks,
        "likes_count": likes_count,
        "tracks_count": tracks.count(),
        "last_comments": comments,
        "liked_track_ids": liked_track_ids,
        "reposted_track_ids": reposted_track_ids,
    })
def track_details_page(request, pk):
    track = get_object_or_404(AudioTrack, pk=pk)
    # tracks = AudioTrack.objects

    
    user_has_liked = False
    user_has_reposted = False
    likes_count = Like.objects.filter(track=track).count()
    reposts_count = Repost.objects.filter(track=track).count()
    if request.user.is_authenticated:
        print("fekla")
        user_has_liked = Like.objects.filter(user=request.user, track=track).exists()
        user_has_reposted = Repost.objects.filter(user=request.user, track=track).exists()
        # likes_count = Like.objects.filter(track=track).count()
        # reposts_count = Repost.objects.filter(track=track).count()
    context = {
        'track': track,
        'user_has_liked': user_has_liked,
        'user_has_reposted': user_has_reposted,
        'likes_count': likes_count,       
        'reposts_count': reposts_count,   

    }
    return render(request, 'details.html', context)

# --- 2. РЕЄСТРАЦІЯ ТА ЛОГІН (БЕЗ CSRF) ---

@method_decorator(csrf_exempt, name='dispatch')
class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer
    permission_classes = [permissions.AllowAny]


class LoginView(ObtainAuthToken):
    def post(self, request, *args, **kwargs):
        response = super().post(request, *args, **kwargs)
        token = Token.objects.get(key=response.data['token'])
        login(request, token.user)  # логинит пользователя в сессию

        return Response({'token': token.key, 'user_id': token.user_id})


class LogoutView(APIView):
    def post(self, request):
        logout(request) # Очищення сесії на сервері
        return Response({"status": "success"})



@csrf_exempt
def logout_view(request):
    logout(request)
    return JsonResponse({"detail": "Logged out"})


class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer

class AudioTrackViewSet(viewsets.ModelViewSet):
    queryset = AudioTrack.objects.all()
    serializer_class = AudioTrackSerializer
    def perform_create(self, serializer):
        serializer.save(user=self.request.user)




class AICommentVectorSearchView(APIView):
    permission_classes = [permissions.AllowAny]
    serializer_class = AISearchTextSerializer

    @swagger_auto_schema(request_body=AISearchTextSerializer)

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        user_text = serializer.validated_data.get('text')
        
        try:
            # 2. Використовуємо ТВІЙ спеціальний метод для генерації вектора
            query_vec = create_embedding(user_text)
        except Exception as e:
            return Response(
                {"detail": f"Помилка ШІ-моделі: {str(e)}"}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

        # 3. Отримуємо з бази коментарі, у яких є ШІ-вектори
        comments = ResearcherComment.objects.filter(embedding_vector__isnull=False).select_related('track')
        if not comments.exists():
            return Response({"detail": "У базі немає коментарів з векторами."}, status=status.HTTP_404_NOT_FOUND)
        
        track_scores = {}

        for comment in comments:
            try:
                comment_vec = comment.embedding_vector
                
                sim = cosine_similarity(query_vec, comment_vec)
                
                similarity_percentage = round(((sim + 1) / 2) * 100, 2)
                track = comment.track
                
                if track.id not in track_scores or similarity_percentage > track_scores[track.id]['similarity']:
                    track_scores[track.id] = {
                        'track_object': track,
                        'similarity': similarity_percentage
                    }
            except Exception:
                continue

        sorted_tracks_data = sorted(track_scores.values(), key=lambda x: x['similarity'], reverse=True)

        results = []
        for item in sorted_tracks_data:
            track = item['track_object']
            track_serializer = AudioTrackSerializer(track, context={'request': request})
            
            track_data = track_serializer.data
            track_data['similarity'] = f"{item['similarity']}%" 
            results.append(track_data)

        return Response(results, status=status.HTTP_200_OK)
class ResearcherCommentViewSet(viewsets.ModelViewSet):

    queryset = ResearcherComment.objects.all()
    serializer_class = ResearcherCommentSerializer
    # Додано обов'язкову перевірку авторизації, щоб уникнути ValueError з AnonymousUser
    # permission_classes = [permissions.IsAuthenticated]
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]
    # permission_classes = [permissions.AllowAny]



    def perform_create(self, serializer):
        instance = serializer.save(user=self.request.user)
        user = self.request.user
        user.points += 50  # Додаємо бали за коментар
        user.save()

class SearchLogViewSet(viewsets.ModelViewSet):
    queryset = SearchLog.objects.all()
    serializer_class = SearchLogSerializer

class AchievementViewSet(viewsets.ModelViewSet):
    queryset = Achievement.objects.all()
    serializer_class = AchievementSerializer

class UserAchievementViewSet(viewsets.ModelViewSet):
    queryset = UserAchievement.objects.all()
    serializer_class = UserAchievementSerializer

class LikeCreateView(APIView):
    # permission_classes = [permissions.IsAuthenticated]
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]
    
    def post(self, request, pk):
        track = get_object_or_404(AudioTrack, pk=pk)
        like, created = Like.objects.get_or_create(user=request.user, track=track)
        
        if not created:
            like.delete()
            is_liked = False
        else:
            is_liked = True
            
        return Response({
            "liked": is_liked,
            "likes_count": track.likes.count()
        }, status=status.HTTP_200_OK)


class RepostCreateView(APIView):
    # permission_classes = [permissions.IsAuthenticated]
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    
    def post(self, request, pk):
        track = get_object_or_404(AudioTrack, pk=pk)
        repost, created = Repost.objects.get_or_create(user=request.user, track=track)
        
        if not created:
            repost.delete()
            is_reposted = False
        else:
            is_reposted = True
            
        return Response({
            "reposted": is_reposted,
            "reposts_count": track.reposts.count()
        }, status=status.HTTP_200_OK)
def search_ai_page_view(request):
    tracks = AudioTrack.objects.all()
    comments = ResearcherComment.objects.all()

    return render(request, "ai_search.html", {"tracks": tracks, "comments": comments})