# Install before running:
# pip install sentence-transformers transformers torch numpy

from sentence_transformers import SentenceTransformer
from transformers import pipeline
import numpy as np

# --- MODELS ---
print("Loading models...")
model = SentenceTransformer("all-MiniLM-L6-v2")
emotion_analyzer = pipeline(
    "text-classification",
    model="j-hartmann/emotion-english-distilroberta-base",
    top_k=None
)

# --- FUNCTIONS ---

def create_embedding(text: str):
    """Create an embedding vector for the given text"""
    return model.encode(text)

def get_emotion(text):
    """Detect the dominant emotion of the text"""
    result = emotion_analyzer(text)
    # Model returns: [[{label, score}, {label, score}, ...]]
    if isinstance(result[0], list):
        result = result[0]
    top_emotion = max(result, key=lambda x: x["score"])
    return top_emotion["label"]

def cosine_similarity(vec1, vec2):
    """Compute cosine similarity between two vectors"""
    return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))
 
# --- DATA ---

#tracks = {
#    "1": "A sad song about lost love",
#    "2": "An energetic rock track for workouts",
#    "3": "A calm melody for rest and sleep",
#    "4": "A track with a cozy and warm atmosphere",
#    "5": "A dark melancholic piano composition",
#    "6": "hard metal"
#}

tracks = {
    "1": "A sad song about lost love",
    "2": "An energetic rock track for workouts",
    "3": "A calm melody for rest and sleep",
    "4": "A track with a cozy and warm atmosphere",
    "5": "A dark melancholic piano composition",
    "6": "Hard metal",
    "7": "A high-energy synthwave track for late-night driving",
    "8": "A bright and cheerful ukulele tune for a sunny day",
    "9": "Aggressive industrial techno with heavy distorted beats",
    "10": "A nostalgic lo-fi hip-hop beat for studying",
    "11": "An epic orchestral soundtrack for a heroic battle",
    "12": "Ethereal ambient pads for deep meditation",
    "13": "A funky bass-driven groove for dancing",
    "14": "Grimy underground trap with dark lyrics",
    "15": "A gentle acoustic guitar ballad about a new beginning",
    "16": "Fast-paced drum and bass for extreme sports",
    "17": "Ethereal bells and distant ocean waves",
    "18": "Soft rain sounds with a lonely flute",
    "19": "Minimalist piano for deep focus",
    "20": "Space ambient with floating synthesizer pads",
    "21": "Morning forest birds with acoustic guitar",
    "22": "Deep breathing sounds mixed with Tibetan bowls",
    "23": "Slow-tempo liquid drum and bass for chilling",
    "24": "Dreamy synth-pop with whispered vocals",
    "25": "Quiet underwater sonar pings and soft drones",
    "26": "Jazz piano in a rainy late-night cafe",
    "27": "Warm analog pads for a sunrise feeling",
    "28": "Soft cello solo for a winter evening",
    "29": "Meditative sitar music with a drone background",
    "30": "Lo-fi beats with a crackling vinyl effect",
    "31": "Fast-paced techno with a heavy kick drum",
    "32": "Aggressive dubstep with robotic growls",
    "33": "High-tempo power metal with shredding guitars",
    "34": "Uplifting trance for a summer festival",
    "35": "Hardcore punk with shouting vocals and fast drums",
    "36": "Brass-heavy orchestral march for a victory scene",
    "37": "Brazilian batucada with intense percussion",
    "38": "Cyberpunk industrial mid-tempo bass",
    "39": "K-pop dance track with a catchy hook",
    "40": "Funky disco with a popping bassline",
    "41": "Moto-rock for highway racing",
    "42": "Intense breakcore with chaotic drum patterns",
    "43": "Trap beat with loud 808 bass and fast hi-hats",
    "44": "Salsa music with energetic trumpet solos",
    "45": "A funeral violin theme",
    "46": "Broken heart ballad with a crying vocal style",
    "47": "Desolate post-rock with echoing guitars",
    "48": "Dark folk song about a cold winter",
    "49": "Slow blues with a soulful organ",
    "50": "Cinematic sad strings for a tragic ending",
    "51": "Hopeless gothic rock with deep vocals",
    "52": "A song about saying goodbye to a friend",
    "53": "Rainy day jazz with a muted trumpet",
    "54": "Atmospheric black metal about loneliness",
    "55": "Minimalist electronic track about isolation",
    "56": "Acoustic version of a rock song, very slow",
    "57": "Orchestral piece for a lost empire",
    "58": "Ukulele and whistling for a commercial vibe",
    "59": "8-bit retro game music for a bonus level",
    "60": "Motown soul with clapping and bright horns",
    "61": "Tropical house with a kalimba melody",
    "62": "Children’s song with a playful piano",
    "63": "Reggae track about sunshine and peace",
    "64": "Swing jazz for a 1920s dance party",
    "65": "Pop-rock anthem about friendship",
    "66": "Celtic folk dance with a fast fiddle",
    "67": "Bossa nova for a beach cocktail",
    "68": "Happy hardcore with high-pitched vocals",
    "69": "Gospel choir singing about hope",
    "70": "Glitch hop with skipping CD sounds",
    "71": "Avant-garde jazz with discordant saxophones",
    "72": "Psychedelic rock with backwards-playing vocals",
    "73": "Tribal drums with alien-like electronic noises",
    "74": "Dark circus music with a creepy accordion",
    "75": "Operatic metal with a dramatic soprano",
    "76": "Noise music consisting of static and screams",
    "77": "Shamanic throat singing with heavy bass",
    "78": "Folk-metal with bagpipes and distorted riffs",
    "79": "Neo-noir soundtrack with a saxophone and rain",
    "80": "Synth-pop about a futuristic city",
    "81": "Old-school boom-bap hip hop",
    "82": "Grunge track with a dusty garage sound",
    "83": "Flamenco guitar with rhythmic handclaps",
    "84": "Country song about a long road trip",
    "85": "Hardstyle with a distorted reverse bass",
    "86": "Trip-hop with a mysterious female vocal",
    "87": "J-rock opening theme for an anime",
    "88": "Classic disco with string arrangements",
    "89": "Nu-metal with rapping and heavy riffs",
    "90": "Medieval bard song with a lute",
    "91": "Eurodance hit from the 90s",
    "92": "Post-punk with a driving bass and cold synths",
    "93": "Reggaeton with a classic dembow rhythm",
    "94": "Cinematic horror tension with screeching strings",
    "95": "Indie-folk with vocal harmonies and banjo",
    "96": "Deep house for a sunset lounge",
    "97": "Soulful R&B with smooth vocal runs",
    "98": "Hardcore rap about street life",
    "99": "Symphonic metal with a full choir",
    "100": "Space-disco with laser sound effects"
}


# Create track embeddings
print("Creating track embeddings...")
track_embeddings = {tid: create_embedding(desc) for tid, desc in tracks.items()}

# --- SEARCH ---

def find_similar_tracks(query, array_tracks, top_k=3):
    query_emb = create_embedding(query)
    print(query_emb)
    query_emotion = get_emotion(query)
    print(f"\nDetected emotion: {query_emotion}\n")

    similarities = {}
    for tid, emb in track_embeddings.items():
        sim = cosine_similarity(query_emb, emb)
        similarities[tid] = sim
    sorted_tracks = sorted(similarities.items(), key=lambda x: x[1], reverse=True)
    results = []
    for tid, score in sorted_tracks:
        track_emotion = get_emotion(array_tracks[tid])
        if track_emotion == query_emotion or len(results) < top_k:
            results.append((tid, score, track_emotion))
        if len(results) >= top_k:
            break
    return results

user_query = "i want is verry extremal"
print(user_query)
results = find_similar_tracks(user_query, tracks)

print("Similar tracks:")
for tid, score, emotion in results:
    print(f"{tracks[tid]} (similarity: {score:.3f}, emotion: {emotion})")

