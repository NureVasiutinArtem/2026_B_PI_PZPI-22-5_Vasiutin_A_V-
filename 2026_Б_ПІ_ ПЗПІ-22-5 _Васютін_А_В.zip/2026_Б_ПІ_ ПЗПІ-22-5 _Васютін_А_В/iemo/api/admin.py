from django.contrib import admin
from .models import User, AudioTrack, ResearcherComment, SearchLog, Achievement, UserAchievement, Like, Repost

# Реєструємо моделі, щоб їх було видно в адмінці
admin.site.register(User)
admin.site.register(AudioTrack)
admin.site.register(ResearcherComment)
admin.site.register(SearchLog)
admin.site.register(Achievement)
admin.site.register(UserAchievement)
admin.site.register(Like)
admin.site.register(Repost)