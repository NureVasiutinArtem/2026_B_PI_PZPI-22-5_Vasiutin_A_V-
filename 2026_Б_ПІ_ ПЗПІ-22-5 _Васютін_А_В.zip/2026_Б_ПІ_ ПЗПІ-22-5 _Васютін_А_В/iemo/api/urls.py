
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework.authtoken.views import obtain_auth_token # Додаємо це для логіна
from .views import (
    AudioTrackViewSet, 
    UserViewSet, 
    ResearcherCommentViewSet, 
    RegisterView,
    SearchLogViewSet,
    LogoutView,
    LoginView,
    AICommentVectorSearchView,
    LikeCreateView,
    RepostCreateView,
    
    research_page,
    track_details_page,
)
from .views import search_view, profile_view, login_page, logout_view, search_ai_page_view
router = DefaultRouter()
router.register(r'tracks', AudioTrackViewSet)
router.register(r'users', UserViewSet)
router.register(r'comments', ResearcherCommentViewSet)
router.register(r'search-logs', SearchLogViewSet)

urlpatterns = [
    path('search/', search_view, name='search-page'),
    path('login/', LoginView.as_view()),
    path('researcher/', research_page, name='research-page'),


    path('register/', RegisterView.as_view(), name='register'),
    path('login/', obtain_auth_token, name='api_token_auth'), 
    path('api/logout/', LogoutView.as_view(), name='api_logout'),
    path('profile/', profile_view, name='profile_view'), # ДОДАЙ ЦЕЙ РЯДОК
    path('search/vector/', AICommentVectorSearchView.as_view(), name='ai-comment-vector-search'),
    path('search-ai/', search_ai_page_view, name='search-ai-page'), # Нова ШІ сторінка

    path('details/<int:pk>/', track_details_page, name='track_details'),
    
    path('api/tracks/<int:pk>/like/', LikeCreateView.as_view(), name='track-like'),
    path('api/tracks/<int:pk>/repost/', RepostCreateView.as_view(), name='track-repost'),
    path('', include(router.urls)),

]