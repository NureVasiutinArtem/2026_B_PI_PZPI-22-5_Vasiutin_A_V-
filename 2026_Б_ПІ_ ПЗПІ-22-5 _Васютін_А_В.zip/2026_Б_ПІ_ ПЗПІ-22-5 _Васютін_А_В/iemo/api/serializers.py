from rest_framework import serializers
from .models import User, AudioTrack, ResearcherComment, SearchLog, Achievement, UserAchievement

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'points', 'rank']

class RegisterSerializer(serializers.ModelSerializer):
    # Виправлено: min_length замість write_length
    password = serializers.CharField(min_length=8, write_only=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password']

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            password=validated_data['password']
        )
        return user

class AudioTrackSerializer(serializers.ModelSerializer):
    class Meta:
        model = AudioTrack
        fields = '__all__'

class AISearchTextSerializer(serializers.Serializer):
    text = serializers.CharField(
        help_text="Введіть ваш текст або емоційний промт для пошуку",    )

# class ResearcherCommentSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = ResearcherComment
#         fields = '__all__'

class ResearcherCommentSerializer(serializers.ModelSerializer):
    # Явно говорим, что это поле только для чтения
    embedding_vector = serializers.JSONField(read_only=True)
    rating = serializers.FloatField(read_only=True)
    useful_count = serializers.IntegerField(read_only=True)

    class Meta:
        model = ResearcherComment
        fields = ['id', 'track', 'content', 'embedding_vector', 'rating', 'useful_count']


class SearchLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = SearchLog
        fields = '__all__'

class AchievementSerializer(serializers.ModelSerializer):
    class Meta:
        model = Achievement
        fields = '__all__'

class UserAchievementSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserAchievement
        fields = '__all__'