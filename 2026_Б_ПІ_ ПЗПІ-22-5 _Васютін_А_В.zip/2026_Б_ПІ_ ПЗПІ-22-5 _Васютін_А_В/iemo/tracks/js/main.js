document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("login-form");

    const registerForm = document.getElementById("register-form");
    if (registerForm) {
        registerForm.addEventListener("submit", function (e) {
            e.preventDefault();
            const formData = new FormData(registerForm);
            const data = {
                username: formData.get("username"),
                email: formData.get("email"),
                password: formData.get("password"),
            };

            fetch("/api/register/", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(data),
            })
                .then((res) => {
                    if (!res.ok) throw res;
                    return res.json();
                })
                .then((data) => {
                    alert("Успішна реєстрація! Тепер ви можете увійти.");
                    window.location.href = "/";
                })
                .catch(async (error) => {
                    let msg = "Помилка реєстрації.";
                    if (error.json) {
                        const err = await error.json();
                        msg = JSON.stringify(err);
                    }
                    alert(msg);
                });
        });
    }
});
